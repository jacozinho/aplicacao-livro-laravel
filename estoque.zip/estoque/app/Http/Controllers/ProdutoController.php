<?php

namespace estoque\Http\Controllers;

use Illuminate\Support\Facades\DB;
use estoque\Produto; 

use Request;


class ProdutoController extends Controller{
	public function lista(){
		// Solução sem ORM - FUNCIONA
		// $produtos = DB::select('select * from produtos');

		// todos os returns abaixo funcionam perfeitamente...		
		
		// return view('produto.listagem')->withProdutos($produtos);		
		
		//return view('produto.listagem', ['produtos'=>$produtos]);

		// $data = ['produtos'=>$produtos];
		// return view('produto.listagem',$data);

		// $data = [];
		// $data['produtos'] = $produtos;
		// return view('produto.listagem',$data);

		// Solução com ORM
		$produtos = Produto::all();

		return view('produto.listagem')->with('produtos',$produtos);
	}

	public function mostra($id){
		//$id = Request::route('id');
		// Solução sem ORM - FUNCIONA
		// $produto = DB::select('select * from produtos where id = ?',[$id]);
		
		//Solução com ORM - funciona
		$produto = Produto::find($id);

		if(empty($produto))
			return 'Esse produto não existe.';
		return view('produto.detalhes')->with('produto',$produto);
	}

	public function novo(){
		return view("produto.formulario");
	}

	public function adiciona(){
		// Solução sem ORM - FUNCIONA
		// pegar dados do formulário
		// $nome = Request::input('nome');
		// $descricao = Request::input('descricao');
		// $quantidade = Request::input('quantidade');
		// $valor = Request::input('valor');

		// salvar no banco de dados
		// DB::insert('insert into produtos
		// (nome,descricao,quantidade,valor)values(?,?,?,?)',
		// array($nome,$descricao,$quantidade,$valor));

		// Solução com ORM - funciona
		// populando os valores - funciona...		
		// $produto = new Produto();
		// $produto->nome = Request::input('nome');
		// $produto->descricao = Request::input('descricao');
		// $produto->quantidade = Request::input('quantidade');
		// $produto->valor = Request::input('valor');

		// Otimizando a obtenção dos valores com ORM - funciona...
		// $params = Request::all();
		// $produto = new Produto($params);

		// Salvando o produto na base de dados
		//$produto->save();

		// Otimizando um pouco mais com ORM - funciona...
		// $params = Request::all();
		// Produto::create($params);
		// ou...
		Produto::create(Request::all());

		// Retornando alguma view - todos funcionan...
		// return view('produto.adicionado')->with('nome',$nome);
		// return view('produto.listagem');
		// return redirect('/produtos')->withInput();
		// return redirect('/produtos')->with(Request::only('nome'));
		return redirect()
			->action('ProdutoController@lista')
			->with(Request::only('nome'));
	}

	public function remove($id){
		//$id = Request::route('id');
		// Solução sem ORM - FUNCIONA
		// $produto = DB::select('delete from produtos where id = ?',[$id]);
		
		//Solução com ORM - funciona
		$produto = Produto::find($id);
		$produto->delete();		

		// if(empty($produto))
		// 	return 'Esse produto não existe.';
		return redirect()->action('ProdutoController@lista');
	}

	public function atualiza($id){

		$produto = Produto::find($id);

		if(empty($produto))
			return 'Esse produto não existe.';
		return view('produto.atualiza')->with('produto',$produto);
	}

	public function atualizar($id){

		$produto = Produto::find($id);

		// pegar dados do formulário
		$produto->nome = Request::input('nome');
		$produto->descricao = Request::input('descricao');
		$produto->quantidade = Request::input('quantidade');
		$produto->valor = Request::input('valor');

		// Salvando o produto na base de dados
		$produto->save();

		return redirect()
			->action('ProdutoController@lista')
			->with(Request::only('nome'));
	}

	public function listaJson(){
		// Solução sem ORM - FUNCIONA
		// $produtos = DB::select('select * from produtos');

		// Solução com ORM
		$produtos = Produto::all();

		return response()->json($produtos);
	}
}