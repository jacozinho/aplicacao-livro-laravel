<!DOCTYPE html>
<html>
<head>
    <title>Controle de Estoque</title>

        <link rel="stylesheet" type="text/css" href="/css/app.css">
</head>
<body>
	<div class="container">
		<?php echo $__env->yieldContent('conteudo'); ?>
	</div>
</body>
</html>