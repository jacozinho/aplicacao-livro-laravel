	<?php $__env->startSection('conteudo'); ?>
	<h1>Detalhes do Produto: <?php echo e($produto->nome); ?></h1>

	<ul>
		<li>Descrição: <?php echo e(isset($produto->descricao) ? $produto->descricao : 'Nenhuma descrição informada'); ?></li>
		<li>Quantidade: <?php echo e($produto->quantidade); ?></li>
		<li>Valor: R$ <?php echo e($produto->valor); ?></li>
	</ul>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>