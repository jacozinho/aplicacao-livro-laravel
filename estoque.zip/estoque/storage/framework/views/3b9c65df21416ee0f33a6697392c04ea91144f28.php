<?php $__env->startSection('conteudo'); ?>
	<h1>Atualizar Produto</h1>

	<form method="post" action="/produtos/atualizar/<?php echo e($produto->id); ?>">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<div class="form-group">
			<label>Nome</label>
			<input name="nome" class="form-control" value="<?php echo e($produto->nome); ?>" />
		</div>
		<div class="form-group">
			<label>Descrição</label>
			<input name="descricao" class="form-control" value="<?php echo e($produto->descricao); ?>"/>
		</div>
		<div class="form-group">
			<label>Quantidade</label>
			<input name="quantidade" type="number" class="form-control" value="<?php echo e($produto->quantidade); ?>" />
		</div>
		<div class="form-group">
			<label>Valor</label>
			<input name="valor" class="form-control" value="<?php echo e($produto->valor); ?>" />
		</div>

		<button type="submit" class="btn btn-primary btn-block">Atualizar</button>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>