@extends('layout.principal')

	@section('conteudo')
	<h1>Detalhes do Produto: {{$produto->nome}}</h1>

	<ul>
		<li>Descrição: {{$produto->descricao or 'Nenhuma descrição informada'}}</li>
		<li>Quantidade: {{$produto->quantidade}}</li>
		<li>Valor: R$ {{$produto->valor}}</li>
	</ul>
	@stop