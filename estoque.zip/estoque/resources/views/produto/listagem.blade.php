@extends('layout.principal')

@section('conteudo')
<h1>Listagem de produtos do estoque com Laravel</h1>


    @if(empty($produtos))
        <div class="alert alert-danger">
            Não há produtos cadastrados.
        </div>
    @else
        <table class="table table-striped table-bordered table-hover">
            <tr>
                <td>Nome</td>
                <td>Descrição</td>
                <td>Quantidade</td>
                <td>Valor</td>
                <td>Visualizar</td>
                <td>Remover</td>
                <td>Atualizar</td>
            </tr>
            @foreach ($produtos as $p)
                <tr class="{{$p->quantidade <= 3 ? 'danger':''}}">
                    <td><b>{{$p->nome}}</b></td> 
                    <td><b>{{$p->descricao}}</b></td> 
                    <td><b>{{$p->quantidade}}</b></td> 
                    <td><b>{{$p->valor}}</b></td>
                    <td>
                        <a href="/produtos/mostra/{{$p->id}}"><span class="glyphicon glyphicon-search"></span></a>
                    </td>
                    <td>
                        <a href="/produtos/remove/{{$p->id}}"><span class="glyphicon glyphicon-trash"></span></a>
                    </td>
                    <td>
                        <a href="/produtos/atualiza/{{$p->id}}"><span class="glyphicon glyphicon-refresh"></span></a>
                    </td>
                </tr>
            @endforeach
        </table>
    @endif
    <h4>
        <span class="label label-danger pull-right">Um ou menos itens no estoque</span>
    </h4>

    @if(old('nome'))
        <div class="alert alert-success">
            <strong>Sucesso!</strong> O produto {{old('nome')}} foi adicionado com sucesso.</b></p>   
        </div>
    @endif
@stop