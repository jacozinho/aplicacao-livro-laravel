<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(ProdutoTableSeeder::class);
    }
}

class ProdutoTableSeeder extends Seeder{
	public function run(){
		DB::insert('insert into produtos
			(nome, descricao, quantidade, valor)values(?,?,?,?)',
			array('Geladeira','Side by Side com gelo na porta',2,590.00));
		DB::insert('insert into produtos
			(nome, descricao, quantidade, valor)values(?,?,?,?)',
			array('Fogão','Painel automático e forno elétrico',5,950.00));
		DB::insert('insert into produtos
			(nome, descricao, quantidade, valor)values(?,?,?,?)',
			array('Microondas','Manda SMS quando termina de esquentar',1,150.00));
	}
}
